# Frame Board

Self-hosted náhrada za DAKboard pre TV na výšku: vlastné fotky, hodiny, dátum a počasie.
Beží ako statická stránka na GitHub Pages, žiadny server ani predplatné.

## Nastavenie

1. Vytvor nový repozitár a nahraj doň obsah tohto priečinka.
2. **Settings → Pages → Source: Deploy from a branch → `main` / root.**
3. **Settings → Actions → General → Workflow permissions → Read and write.**
4. Nahraj fotky do priečinka `photos/`. Action automaticky aktualizuje `photos.json`.
5. Na TV otvor prehliadač a zadaj `https://<tvoj-username>.github.io/<repo>/`.

## Parametre v URL

| Parameter  | Predvolené | Význam                          |
|------------|------------|---------------------------------|
| `lat`,`lon`| Bratislava | poloha pre počasie              |
| `interval` | `60`       | sekundy na jednu fotku          |
| `shuffle`  | `1`        | `0` = v poradí podľa názvu      |
| `caption`  | `1`        | `0` = skryť názov fotky dole    |

Príklad: `.../?lat=48.21&lon=16.37&interval=300`

## Tipy

- Fotky zmenši na cca 2160 px na výšku, TV prehliadač je pomalý pri 10 MB súboroch:
  `mogrify -resize '2160x3840>' -quality 88 photos/*.jpg`
- Názov súboru sa zobrazuje ako popis (`zapad-slnka_tatry.jpg` → „zapad slnka tatry“).
- Počasie: [Open-Meteo](https://open-meteo.com), bez API kľúča.
- Pri verejnom repozitári sú fotky verejné. GitHub Pages pre súkromné repo vyžaduje GitHub Pro.
